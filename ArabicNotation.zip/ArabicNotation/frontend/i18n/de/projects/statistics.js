export default {
  statistics: 'Statistiken',
  progress: [
    'Abgeschlossen',
    'Unvollständig'
  ],
  labelStats: 'Labelstatistiken',
  userStats: 'Nutzerstatistiken'
}
