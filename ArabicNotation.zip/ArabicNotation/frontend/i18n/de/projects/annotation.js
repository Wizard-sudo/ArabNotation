export default {
  checkedTooltip: 'Geprüft',
  notCheckedTooltip: 'Nicht geprüft',
  selectFilterTooltip: 'Wähle einen Filter',
  filterOption1: 'Alle',
  filterOption2: 'Erledigt',
  filterOption3: 'Unerledigt',
  guidelineTooltip: 'Zeige Leitfaden',
  guidelinePopupTitle: 'Annotationsleitfaden',
  metadataDefaultMessage: 'Keine Daten verfügbar',
  key: 'Schlüssel',
  value: 'Wert',
  newText: 'Neuer Text'
}
