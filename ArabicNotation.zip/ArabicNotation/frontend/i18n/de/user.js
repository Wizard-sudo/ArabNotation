export default {
  login: 'Einloggen',
  signOut: 'Ausloggen',
  username: 'Benutzername',
  password: 'Passwort'
}
