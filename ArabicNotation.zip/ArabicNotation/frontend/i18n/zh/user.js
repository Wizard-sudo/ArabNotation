export default {
  login: '登录',
  signOut: '注销',
  username: '用户名',
  password: '密码'
}
