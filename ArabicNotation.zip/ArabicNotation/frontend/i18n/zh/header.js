export default {
  projects: '项目'
}
