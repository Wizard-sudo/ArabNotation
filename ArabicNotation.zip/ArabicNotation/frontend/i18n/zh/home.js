export default {
  mainTitle: '文本标注平台',
  getStarted: '快速开始',
  startAnnotation: '开始标注',
  featuresTitle: '最大特色',
  featuresTitle1: '团队合作',
  featuresText1: '与你的团队标注',
  featuresTitle2: '任何语言',
  featuresText2: '用任何语言标注',
  featuresTitle3: '免费开源',
  featuresText3: '免费可自定义',
  footerTitle: '尽快实现你的想法',
  demoDropDown: '试一试',
  demoNER: '命名实体识别',
  demoSent: '情感分析',
  demoTranslation: '文本翻译',
  demoTextToSQL: '语义解析Text-to-SQL'
}
