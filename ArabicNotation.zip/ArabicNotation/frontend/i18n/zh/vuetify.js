export default {
  itemsPerPageText: '每页最多可显示',
  noDataAvailable: '没有数据可获得'
}
