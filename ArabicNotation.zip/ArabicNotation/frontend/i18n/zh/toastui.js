export default {
  localeCode: 'zh_CN'
}
