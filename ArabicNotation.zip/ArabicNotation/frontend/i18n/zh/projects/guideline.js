export default {
  guideline: '指南',
  writeGuidelinePrompt: '请写入标注指南'
}
