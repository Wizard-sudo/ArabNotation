export default {
  comments: '评论',
  removeComment: '删除评论',
  removePrompt: '确定要删除评论吗?',
  commentView: '查看',
  created_at: '创建',
  document: '文档',
  send: '发送',
  message: '消息'
}
