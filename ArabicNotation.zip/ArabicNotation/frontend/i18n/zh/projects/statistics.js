export default {
  statistics: '统计',
  progress: [
    '已完成',
    '未完成'
  ],
  labelStats: '标签统计',
  userStats: '用户统计'
}
