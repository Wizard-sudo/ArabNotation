export default {
  fileCannotUpload: '这个文件不能被上传，获取格式错误，请仔细检查文件格式',
  labelCannotCreate: '这个标签不能被创建，你可能在其它的键上用了相同的标签名',
  invalidUserOrPass: '用户名或者密码不正确'
}
