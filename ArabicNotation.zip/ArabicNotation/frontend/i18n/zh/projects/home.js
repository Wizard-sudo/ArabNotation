export default {
  home: '主页',
  welcome: '欢迎进入数据标注平台',
  importData: '导入数据集',
  createLabels: '为这个项目创建标签名',
  addMembers: '添加成员',
  defineGuideline: '定义指南',
  annotateDataset: '标注数据集',
  viewStatistics: '查看统计',
  exportDataset: '导出数据集'
}
