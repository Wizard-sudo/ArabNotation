export default {
  login: 'Login',
  signOut: 'Sign Out',
  username: 'Username',
  password: 'Password'
}
