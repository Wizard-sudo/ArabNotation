export default {
  title: 'Settings'
}
