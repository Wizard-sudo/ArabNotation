export default {
  login: 'Connexion',
  signOut: 'Déconnexion',
  username: 'Nom d\'utilisateur',
  password: 'Mot de passe'
}
