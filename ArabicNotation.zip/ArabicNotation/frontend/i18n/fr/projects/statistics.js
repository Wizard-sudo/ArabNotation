export default {
  statistics: 'Statistiques',
  progress: [
    'Complété',
    'Incomplet'
  ],
  labelStats: 'Étiqueter les stats',
  userStats: 'Stats des utilisateurs'
}
