export default {
  checkedTooltip: 'Vérifié',
  notCheckedTooltip: 'Non vérifié',
  selectFilterTooltip: 'Sélectionnez un filtre',
  filterOption1: 'Tous',
  filterOption2: 'Terminé',
  filterOption3: 'Non terminé',
  guidelineTooltip: 'Afficher la ligne directrice',
  guidelinePopupTitle: 'Ligne directrice pour les annotations',
  metadataDefaultMessage: 'Aucune donnée disponible',
  key: 'Clé',
  value: 'Valeur',
  newText: 'Nouveau texte'
}
