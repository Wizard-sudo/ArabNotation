export default {
  fileCannotUpload: 'Le fichier n\'a pas pu être téléchargé. Peut-être un format non valide.\n Veuillez vérifier attentivement les formats disponibles.',
  labelCannotCreate: 'L\'étiquette n\'a pas pu être créé.\n Vous ne pouvez pas utiliser le même nom d\'étiquette ou la même raccourci clavier.',
  invalidUserOrPass: 'Nom d\'utilisateur ou mot de passe incorrect, ou quelque chose a mal tourné.'
}
