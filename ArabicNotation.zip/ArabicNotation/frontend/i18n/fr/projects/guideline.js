export default {
  guideline: 'Ligne directrice',
  writeGuidelinePrompt: 'Veuillez rédiger le guide d\'annotation.'
}
