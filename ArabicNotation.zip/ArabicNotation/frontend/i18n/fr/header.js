export default {
  projects: 'projets'
}
