export default {
  itemsPerPageText: 'Lignes par page',
  noDataAvailable: 'Aucune donnée disponible'
}
