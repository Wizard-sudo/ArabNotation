export default {
  localeCode: 'fr_FR'
}
