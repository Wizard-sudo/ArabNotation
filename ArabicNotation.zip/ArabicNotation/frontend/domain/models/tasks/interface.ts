
export interface AnnotationModel {
  valueOf(values: object): any
  toObject(): object
}
