export class Status {
  ready: boolean;
  result: object;
  error: any;
}
