from django.apps import AppConfig


class ApiConfig(AppConfig):
    name = "api"
    verbose_name = "Api"
